'use strict';

const { Router } = require('express');
const multer                        = require('multer');
const dossieLocalizacaoController   = require('../controllers/dossieLocalizacao.controller');
const validate                      = require('../middlewares/validate.middleware');
const { salvarLocalizacaoValidator } = require('../validators/dossieLocalizacao.validator');

const router = Router({ mergeParams: true });

/**
 * Multer configurado para upload de PDF em memória.
 * Aceita apenas application/pdf.
 * Limite de 10 MB por arquivo.
 */
const uploadPdf = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const isMimePdf = file.mimetype === 'application/pdf';
    const isExtPdf  = /\.pdf$/i.test(file.originalname);
    if (!isMimePdf || !isExtPdf) {
      return cb(new Error('Apenas arquivos PDF são aceitos.'));
    }
    cb(null, true);
  },
});

// Autenticação já aplicada pelo router pai (dossie.routes.js)

// Buscar dados de localização de um dossiê
router.get(  '/',     dossieLocalizacaoController.buscar);

// Salvar (upsert) dados de localização
router.post( '/',     salvarLocalizacaoValidator, validate, dossieLocalizacaoController.salvar);

// Upload do PDF
router.post( '/pdf',          uploadPdf.single('arquivo'), dossieLocalizacaoController.uploadPdf);

// Download seguro do PDF (autenticado via JWT)
router.get(  '/pdf/download', dossieLocalizacaoController.downloadPdf);

// Remover o PDF
router.delete('/pdf',         dossieLocalizacaoController.removerPdf);

module.exports = router;
