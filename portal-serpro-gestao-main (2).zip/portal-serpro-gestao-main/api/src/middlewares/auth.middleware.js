'use strict';

const { verify } = require('../config/jwt');
const AppError   = require('../utils/AppError');

/**
 * Middleware de autenticação JWT.
 * Aceita o Bearer Token via:
 *   1. Cabeçalho Authorization: Bearer <token>  (padrão)
 *   2. Query string ?token=<token>               (apenas para downloads diretos como PDF)
 * Injeta req.user com o payload decodificado.
 */
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  // Extrai token: primeiro do cabeçalho, depois da query string
  let token = null;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  } else if (req.query && req.query.token) {
    // Aceito apenas em rotas de download (segurança básica: apenas GET)
    if (req.method === 'GET') {
      token = req.query.token;
    }
  }

  if (!token) {
    throw new AppError('Token de autenticação ausente ou malformado.', 401, 'MISSING_TOKEN');
  }

  try {
    req.user = verify(token);
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      throw new AppError('Sessão expirada. Faça login novamente.', 401, 'TOKEN_EXPIRED');
    }
    throw new AppError('Token inválido.', 401, 'INVALID_TOKEN');
  }
}

module.exports = authMiddleware;
