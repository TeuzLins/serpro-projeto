'use strict';

const db = require('../config/database');

/**
 * Repositório de Localização Física de Dossiês.
 * Utiliza estratégia UPSERT para garantir no máximo um registro por dossiê.
 */
const dossieLocalizacaoRepository = {
  /**
   * Busca os dados de localização pelo ID do dossiê.
   * @param {number} dossieId
   * @returns {object|null}
   */
  async findByDossieId(dossieId) {
    const result = await db.query(
      'SELECT * FROM dossie_localizacao WHERE dossie_id = $1',
      [dossieId],
    );
    return result.rows[0] || null;
  },

  /**
   * Cria ou atualiza os dados de localização (UPSERT por dossie_id).
   * O setor é sempre fixado como SUPGP conforme regra de negócio.
   * @param {number} dossieId
   * @param {object} dados
   * @returns {object}
   */
  async upsert(dossieId, { localizacaoFisica, codigoCaixa, descricao, observacoes }) {
    const result = await db.query(
      `INSERT INTO dossie_localizacao
         (dossie_id, localizacao_fisica, codigo_caixa, setor, descricao, observacoes)
       VALUES ($1, $2, $3, 'SUPGP', $4, $5)
       ON CONFLICT (dossie_id)
       DO UPDATE SET
         localizacao_fisica = EXCLUDED.localizacao_fisica,
         codigo_caixa       = EXCLUDED.codigo_caixa,
         setor              = 'SUPGP',
         descricao          = EXCLUDED.descricao,
         observacoes        = EXCLUDED.observacoes,
         updated_at         = NOW()
       RETURNING *`,
      [
        dossieId,
        (localizacaoFisica || '').trim() || null,
        (codigoCaixa       || '').trim() || null,
        (descricao         || '').trim() || null,
        (observacoes       || '').trim() || null,
      ],
    );
    return result.rows[0];
  },

  /**
   * Atualiza apenas o caminho e nome do arquivo PDF vinculado.
   * Cria o registro com upsert se não existir.
   * @param {number} dossieId
   * @param {string} caminhoArquivoPdf
   * @param {string} nomeArquivoPdf
   * @returns {object}
   */
  async updatePdf(dossieId, caminhoArquivoPdf, nomeArquivoPdf) {
    const result = await db.query(
      `INSERT INTO dossie_localizacao
         (dossie_id, setor, caminho_arquivo_pdf, nome_arquivo_pdf)
       VALUES ($1, 'SUPGP', $2, $3)
       ON CONFLICT (dossie_id)
       DO UPDATE SET
         caminho_arquivo_pdf = EXCLUDED.caminho_arquivo_pdf,
         nome_arquivo_pdf    = EXCLUDED.nome_arquivo_pdf,
         updated_at          = NOW()
       RETURNING *`,
      [dossieId, caminhoArquivoPdf, nomeArquivoPdf],
    );
    return result.rows[0];
  },

  /**
   * Remove o arquivo PDF vinculado ao dossiê (somente campos, não o registro).
   * @param {number} dossieId
   * @returns {object|null}
   */
  async removePdf(dossieId) {
    const result = await db.query(
      `UPDATE dossie_localizacao
          SET caminho_arquivo_pdf = NULL,
              nome_arquivo_pdf    = NULL,
              updated_at          = NOW()
        WHERE dossie_id = $1
        RETURNING *`,
      [dossieId],
    );
    return result.rows[0] || null;
  },
};

module.exports = dossieLocalizacaoRepository;
