'use strict';

const { body } = require('express-validator');

/**
 * Validação para salvar localização física do dossiê.
 * Todos os campos são opcionais, mas quando presentes são normalizados.
 */
const salvarLocalizacaoValidator = [
  body('localizacaoFisica')
    .optional({ nullable: true, checkFalsy: true })
    .isString()
    .withMessage('Localização física deve ser um texto.')
    .trim()
    .isLength({ max: 500 })
    .withMessage('Localização física não pode exceder 500 caracteres.'),

  body('codigoCaixa')
    .optional({ nullable: true, checkFalsy: true })
    .isString()
    .withMessage('Código da caixa deve ser um texto.')
    .trim()
    .isLength({ max: 100 })
    .withMessage('Código da caixa não pode exceder 100 caracteres.'),

  body('descricao')
    .optional({ nullable: true, checkFalsy: true })
    .isString()
    .withMessage('Descrição deve ser um texto.')
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Descrição não pode exceder 2000 caracteres.'),

  body('observacoes')
    .optional({ nullable: true, checkFalsy: true })
    .isString()
    .withMessage('Observações devem ser um texto.')
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Observações não podem exceder 2000 caracteres.'),
];

module.exports = { salvarLocalizacaoValidator };
