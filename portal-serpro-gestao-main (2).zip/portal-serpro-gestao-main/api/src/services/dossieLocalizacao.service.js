'use strict';

const path                        = require('path');
const fs                          = require('fs');
const { v4: uuidv4 }              = require('uuid');
const dossieLocalizacaoRepository = require('../repositories/dossieLocalizacao.repository');
const dossieRepository            = require('../repositories/dossie.repository');
const AppError                    = require('../utils/AppError');

/** Diretório onde os PDFs serão salvos dentro do container */
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.join('/app', 'uploads', 'dossies');

/** Tamanho máximo permitido para o PDF (10 MB) */
const MAX_PDF_SIZE = parseInt(process.env.MAX_PDF_SIZE || String(10 * 1024 * 1024), 10);

/**
 * Garante que o diretório de uploads existe.
 */
function ensureUploadsDir() {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

const dossieLocalizacaoService = {
  /**
   * Verifica se o dossiê existe e retorna seus dados.
   * @param {number} dossieId
   */
  async _assertDossieExiste(dossieId) {
    const dossie = await dossieRepository.findById(dossieId);
    if (!dossie) {
      throw new AppError(`Dossiê com ID ${dossieId} não encontrado.`, 404, 'NOT_FOUND');
    }
    return dossie;
  },

  /**
   * Busca os dados de localização de um dossiê.
   * Retorna null se ainda não existir registro.
   * @param {number} dossieId
   */
  async buscarPorDossieId(dossieId) {
    await this._assertDossieExiste(dossieId);
    return dossieLocalizacaoRepository.findByDossieId(dossieId);
  },

  /**
   * Cria ou atualiza os dados de localização física (UPSERT).
   * @param {number} dossieId
   * @param {object} dados
   */
  async salvar(dossieId, dados) {
    await this._assertDossieExiste(dossieId);
    return dossieLocalizacaoRepository.upsert(dossieId, dados);
  },

  /**
   * Processa e salva o PDF enviado via upload.
   * Valida tipo e tamanho, remove arquivo anterior se existir,
   * salva o novo e atualiza o registro no banco.
   *
   * @param {number} dossieId
   * @param {object} file    - Objeto multer { buffer, originalname, mimetype, size }
   * @returns {object}       - Registro atualizado
   */
  async uploadPdf(dossieId, file) {
    await this._assertDossieExiste(dossieId);

    // Validação de tipo MIME e extensão
    const isMimePdf = file.mimetype === 'application/pdf';
    const isExtPdf  = /\.pdf$/i.test(file.originalname);
    if (!isMimePdf || !isExtPdf) {
      throw new AppError('Apenas arquivos PDF são aceitos.', 400, 'INVALID_FILE_TYPE');
    }

    // Validação de tamanho
    if (file.size > MAX_PDF_SIZE) {
      const limitMB = Math.round(MAX_PDF_SIZE / 1024 / 1024);
      throw new AppError(`O arquivo excede o limite de ${limitMB} MB.`, 400, 'FILE_TOO_LARGE');
    }

    ensureUploadsDir();

    // Remove arquivo PDF anterior se existir
    const existing = await dossieLocalizacaoRepository.findByDossieId(dossieId);
    if (existing && existing.caminho_arquivo_pdf) {
      const oldPath = existing.caminho_arquivo_pdf;
      if (fs.existsSync(oldPath)) {
        try { fs.unlinkSync(oldPath); } catch (_) { /* ignora falha na remoção do arquivo antigo */ }
      }
    }

    // Gera nome único para o arquivo
    const ext      = path.extname(file.originalname).toLowerCase();
    const filename = `${dossieId}_${uuidv4()}${ext}`;
    const filepath = path.join(UPLOADS_DIR, filename);

    // Grava o arquivo em disco
    fs.writeFileSync(filepath, file.buffer);

    // Persiste o caminho no banco
    return dossieLocalizacaoRepository.updatePdf(dossieId, filepath, file.originalname);
  },

  /**
   * Remove o arquivo PDF vinculado ao dossiê.
   * Deleta o arquivo físico e limpa os campos no banco.
   * @param {number} dossieId
   */
  async removerPdf(dossieId) {
    await this._assertDossieExiste(dossieId);

    const existing = await dossieLocalizacaoRepository.findByDossieId(dossieId);
    if (!existing || !existing.caminho_arquivo_pdf) {
      throw new AppError('Nenhum arquivo PDF vinculado a este dossiê.', 404, 'NO_PDF_FOUND');
    }

    if (fs.existsSync(existing.caminho_arquivo_pdf)) {
      try { fs.unlinkSync(existing.caminho_arquivo_pdf); } catch (_) { /* ignora */ }
    }

    return dossieLocalizacaoRepository.removePdf(dossieId);
  },
};

module.exports = dossieLocalizacaoService;
