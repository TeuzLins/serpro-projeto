'use strict';

const fs                       = require('fs');
const path                     = require('path');
const dossieLocalizacaoService = require('../services/dossieLocalizacao.service');
const dossieLocalizacaoRepo    = require('../repositories/dossieLocalizacao.repository');
const AppError                 = require('../utils/AppError');
const { ok }                   = require('../utils/response');

const dossieLocalizacaoController = {
  /**
   * GET /api/v1/dossies/:id/localizacao
   * Retorna os dados de localização física do dossiê.
   */
  async buscar(req, res) {
    const dossieId = parseInt(req.params.id, 10);
    const dados = await dossieLocalizacaoService.buscarPorDossieId(dossieId);
    return ok(res, dados);
  },

  /**
   * POST /api/v1/dossies/:id/localizacao
   * Cria ou atualiza (upsert) os dados de localização física.
   */
  async salvar(req, res) {
    const dossieId = parseInt(req.params.id, 10);
    const dados = await dossieLocalizacaoService.salvar(dossieId, req.body);
    return ok(res, dados, 'Localização física salva com sucesso.');
  },

  /**
   * POST /api/v1/dossies/:id/localizacao/pdf
   * Realiza o upload do arquivo PDF vinculado ao dossiê.
   */
  async uploadPdf(req, res) {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Nenhum arquivo enviado.',
      });
    }
    const dossieId = parseInt(req.params.id, 10);
    const dados = await dossieLocalizacaoService.uploadPdf(dossieId, req.file);
    return ok(res, dados, 'Arquivo PDF enviado com sucesso.');
  },

  /**
   * DELETE /api/v1/dossies/:id/localizacao/pdf
   * Remove o arquivo PDF vinculado ao dossiê.
   */
  async removerPdf(req, res) {
    const dossieId = parseInt(req.params.id, 10);
    const dados = await dossieLocalizacaoService.removerPdf(dossieId);
    return ok(res, dados, 'Arquivo PDF removido com sucesso.');
  },

  /**
   * GET /api/v1/dossies/:id/localizacao/pdf/download
   * Faz stream do arquivo PDF vinculado ao dossiê.
   * Requer autenticação (JWT).
   */
  async downloadPdf(req, res) {
    const dossieId = parseInt(req.params.id, 10);
    const dados = await dossieLocalizacaoRepo.findByDossieId(dossieId);

    if (!dados || !dados.caminho_arquivo_pdf) {
      throw new AppError('Nenhum arquivo PDF vinculado a este dossiê.', 404, 'NO_PDF_FOUND');
    }

    const filePath = dados.caminho_arquivo_pdf;
    if (!fs.existsSync(filePath)) {
      throw new AppError('Arquivo PDF não encontrado no servidor.', 404, 'FILE_NOT_FOUND');
    }

    const fileName = dados.nome_arquivo_pdf || path.basename(filePath);
    const stat     = fs.statSync(filePath);

    res.setHeader('Content-Type',        'application/pdf');
    res.setHeader('Content-Length',      stat.size);
    res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(fileName)}"`);
    res.setHeader('X-Content-Type-Options', 'nosniff');

    fs.createReadStream(filePath).pipe(res);
  },
};

module.exports = dossieLocalizacaoController;
